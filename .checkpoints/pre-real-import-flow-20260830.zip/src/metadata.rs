use crate::{
    engine,
    models::{PersonalDemo, Playlist, Recommendation, RouteStep, TasteReport, Track, VersionType},
    normalize::{normalize_text, token_similarity},
};
use reqwest::Client;
use serde::Deserialize;
use std::{collections::HashSet, time::Duration};
use tokio::time::timeout;
use uuid::Uuid;

#[derive(Clone)]
pub struct MetadataService {
    client: Client,
    storefront: String,
    max_tracks: usize,
}

impl MetadataService {
    pub fn new() -> Self {
        let client = Client::builder()
            .timeout(Duration::from_secs(7))
            .user_agent("MelodyPath/0.1 (local music analysis course project)")
            .build()
            .unwrap_or_default();
        Self {
            client,
            storefront: std::env::var("ITUNES_STOREFRONT").unwrap_or_else(|_| "CN".into()),
            max_tracks: std::env::var("LOCAL_ANALYSIS_MAX_TRACKS")
                .ok()
                .and_then(|value| value.parse().ok())
                .unwrap_or(40),
        }
    }

    /// 无需音乐平台账号：先匹配 Apple 公开目录，失败时使用本地艺术家知识库。
    /// 网络不可用时也会返回基础统计，不会让整个分析失败。
    pub async fn analyze(&self, mut playlist: Playlist) -> PersonalDemo {
        let enrich_count = playlist.tracks.len().min(self.max_tracks);
        for track in playlist.tracks.iter_mut().take(enrich_count) {
            let matched = match timeout(Duration::from_secs(8), self.lookup_itunes(track)).await {
                Ok(Ok(Some(candidate))) => {
                    apply_itunes_candidate(track, candidate);
                    true
                }
                _ => false,
            };
            if !matched {
                apply_local_artist_profile(track);
            }
        }

        if playlist.tracks.len() > enrich_count {
            for track in playlist.tracks.iter_mut().skip(enrich_count) {
                apply_local_artist_profile(track);
            }
        }

        let report = engine::analyze_playlist(&playlist);
        let recommendations = build_local_recommendations(&playlist, &report);
        let route = build_route(&report, &recommendations);
        PersonalDemo {
            playlist,
            report,
            recommendations,
            route,
        }
    }

    async fn lookup_itunes(&self, source: &Track) -> Result<Option<ItunesTrack>, reqwest::Error> {
        let artist = source.artists.first().cloned().unwrap_or_default();
        let term = format!("{} {}", artist, source.title);
        let response = self
            .client
            .get("https://itunes.apple.com/search")
            .query(&[
                ("term", term.as_str()),
                ("media", "music"),
                ("entity", "song"),
                ("limit", "8"),
                ("country", self.storefront.as_str()),
            ])
            .send()
            .await?
            .error_for_status()?
            .json::<ItunesResponse>()
            .await?;

        Ok(response
            .results
            .into_iter()
            .filter(|item| item.track_name.is_some() && item.artist_name.is_some())
            .map(|item| {
                let title_score = token_similarity(
                    &source.title,
                    item.track_name.as_deref().unwrap_or_default(),
                );
                let artist_score = source
                    .artists
                    .iter()
                    .map(|artist| {
                        token_similarity(artist, item.artist_name.as_deref().unwrap_or_default())
                    })
                    .fold(0.0_f32, f32::max);
                let score = title_score * 0.62 + artist_score * 0.38;
                (score, item)
            })
            .filter(|(score, _)| *score >= 0.52)
            .max_by(|a, b| a.0.total_cmp(&b.0))
            .map(|(_, item)| item))
    }
}

#[derive(Debug, Deserialize)]
struct ItunesResponse {
    #[serde(default)]
    results: Vec<ItunesTrack>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ItunesTrack {
    track_id: Option<u64>,
    track_name: Option<String>,
    artist_name: Option<String>,
    collection_name: Option<String>,
    primary_genre_name: Option<String>,
    release_date: Option<String>,
    track_time_millis: Option<u32>,
    track_view_url: Option<String>,
    preview_url: Option<String>,
}

fn apply_itunes_candidate(track: &mut Track, candidate: ItunesTrack) {
    if let Some(title) = candidate.track_name {
        track.title = title.clone();
        track.normalized_title = normalize_text(&title);
    }
    if let Some(artist) = candidate.artist_name {
        track.artists = vec![artist];
    }
    track.album = candidate.collection_name;
    let genre = canonical_genre(candidate.primary_genre_name.as_deref().unwrap_or("其他"));
    track.genres = vec![genre.clone()];
    track.release_year = candidate
        .release_date
        .as_deref()
        .and_then(|value| value.get(..4))
        .and_then(|value| value.parse().ok());
    track.duration_ms = candidate.track_time_millis;
    track.platform = "public_catalog".into();
    track.platform_url = candidate.track_view_url;
    if let Some(id) = candidate.track_id {
        track.external_ids.insert("itunes".into(), id.to_string());
    }
    if let Some(preview) = candidate.preview_url {
        track.external_ids.insert("preview_url".into(), preview);
    }
    let (moods, energy) = genre_features(&genre);
    track.mood_tags = moods;
    track.energy_score = Some(energy);
    track.language = infer_language(&format!("{} {}", track.title, track.artists.join(" ")));
    track.metadata_confidence = 0.88;
}

fn apply_local_artist_profile(track: &mut Track) {
    let artist = normalize_text(
        track
            .artists
            .first()
            .map(String::as_str)
            .unwrap_or_default(),
    );
    let profile = artist_profile(&artist);
    if let Some((genres, language, energy, moods)) = profile {
        track.genres = genres.iter().map(|value| (*value).to_string()).collect();
        track.language = Some(language.into());
        track.energy_score = Some(energy);
        track.mood_tags = moods.iter().map(|value| (*value).to_string()).collect();
        track.metadata_confidence = 0.68;
    } else {
        track.genres = vec!["元数据待补全".into()];
        track.language = infer_language(&format!("{} {}", track.title, track.artists.join(" ")));
        track.metadata_confidence = 0.35;
    }
}

fn artist_profile(
    artist: &str,
) -> Option<(
    &'static [&'static str],
    &'static str,
    f32,
    &'static [&'static str],
)> {
    let profile = match artist {
        "bibi" | "dean" | "crush" | "heize" | "colde" | "keshi" => (
            &["Korean R&B", "Alternative R&B"][..],
            "韩语/英语",
            0.52,
            &["夜色", "细腻"][..],
        ),
        "newjeans" | "ive" | "le sserafim" | "aespa" | "blackpink" | "bts" | "iu" => (
            &["K-Pop", "Dance Pop"][..],
            "韩语",
            0.72,
            &["明亮", "律动"][..],
        ),
        "周杰伦" | "jay chou" | "陈奕迅" | "eason chan" | "邓紫棋" | "g e m" | "五月天"
        | "毛不易" => (
            &["Mandopop", "C-Pop"][..],
            "中文",
            0.58,
            &["叙事", "怀旧"][..],
        ),
        "宇多田光" | "hikaru utada" | "mariya takeuchi" | "竹内まりや" | "藤井风"
        | "fujii kaze" | "yoasobi" | "aimer" => (
            &["J-Pop", "Japanese R&B"][..],
            "日语",
            0.56,
            &["细腻", "都市"][..],
        ),
        "frank ocean" | "daniel caesar" | "sza" | "the weeknd" | "solange" | "masego" => (
            &["R&B / Soul", "Alternative R&B"][..],
            "英语",
            0.55,
            &["夜色", "柔和"][..],
        ),
        "arctic monkeys" | "the 1975" | "radiohead" | "coldplay" | "the cranberries"
        | "tame impala" => (
            &["Alternative Rock", "Indie Rock"][..],
            "英语",
            0.69,
            &["张力", "迷幻"][..],
        ),
        "taylor swift" | "dua lipa" | "billie eilish" | "lana del rey" | "olivia rodrigo" => (
            &["Pop", "Singer/Songwriter"][..],
            "英语",
            0.62,
            &["流行", "叙事"][..],
        ),
        "laufey" => (
            &["Jazz Pop", "Singer/Songwriter"][..],
            "英语",
            0.39,
            &["温暖", "复古"][..],
        ),
        _ => return None,
    };
    Some(profile)
}

fn canonical_genre(raw: &str) -> String {
    let normalized = raw.trim();
    match normalized.to_lowercase().as_str() {
        "r&b/soul" | "r&b" | "soul" => "R&B / Soul".into(),
        "hip-hop/rap" | "hip hop/rap" => "Hip-Hop / Rap".into(),
        "alternative" => "Alternative / Indie".into(),
        "singer/songwriter" => "Singer/Songwriter".into(),
        "k-pop" => "K-Pop".into(),
        "j-pop" => "J-Pop".into(),
        "mandopop" => "Mandopop".into(),
        _ => normalized.to_string(),
    }
}

fn genre_features(genre: &str) -> (Vec<String>, f32) {
    let lower = genre.to_lowercase();
    let (moods, energy): (&[&str], f32) = if lower.contains("rock") {
        (&["张力", "热烈"], 0.78)
    } else if lower.contains("hip-hop") || lower.contains("rap") {
        (&["节奏", "自信"], 0.75)
    } else if lower.contains("electronic") || lower.contains("dance") {
        (&["律动", "明亮"], 0.82)
    } else if lower.contains("r&b") || lower.contains("soul") {
        (&["细腻", "夜色"], 0.52)
    } else if lower.contains("jazz") {
        (&["松弛", "复古"], 0.43)
    } else if lower.contains("classical") {
        (&["平静", "专注"], 0.28)
    } else if lower.contains("folk") || lower.contains("singer") {
        (&["叙事", "温暖"], 0.42)
    } else if lower.contains("alternative") || lower.contains("indie") {
        (&["独立", "迷幻"], 0.61)
    } else {
        (&["流行", "明亮"], 0.64)
    };
    (
        moods.iter().map(|value| (*value).to_string()).collect(),
        energy,
    )
}

fn infer_language(text: &str) -> Option<String> {
    let mut has_hangul = false;
    let mut has_kana = false;
    let mut has_han = false;
    for ch in text.chars() {
        let code = ch as u32;
        has_hangul |= (0xAC00..=0xD7AF).contains(&code);
        has_kana |= (0x3040..=0x30FF).contains(&code);
        has_han |= (0x4E00..=0x9FFF).contains(&code);
    }
    if has_hangul {
        Some("韩语".into())
    } else if has_kana {
        Some("日语".into())
    } else if has_han {
        Some("中文/日语".into())
    } else {
        Some("英语/其他".into())
    }
}

fn build_local_recommendations(playlist: &Playlist, report: &TasteReport) -> Vec<Recommendation> {
    let source_keys: HashSet<String> = playlist
        .tracks
        .iter()
        .map(|track| {
            format!(
                "{}|{}",
                normalize_text(&track.title),
                normalize_text(&track.artists.join(" "))
            )
        })
        .collect();
    let source_genres: HashSet<String> = report
        .genre_distribution
        .iter()
        .map(|(genre, _)| genre.clone())
        .filter(|genre| !genre.contains("待补全"))
        .collect();
    let adjacent: HashSet<String> =
        engine::adjacent_genres(&source_genres.iter().cloned().collect::<Vec<_>>())
            .into_iter()
            .collect();
    let avg_energy = playlist
        .tracks
        .iter()
        .filter_map(|track| track.energy_score)
        .sum::<f32>()
        / playlist
            .tracks
            .iter()
            .filter(|track| track.energy_score.is_some())
            .count()
            .max(1) as f32;

    let mut scored: Vec<(i32, f32, Track)> = recommendation_pool()
        .into_iter()
        .filter(|track| {
            !source_keys.contains(&format!(
                "{}|{}",
                normalize_text(&track.title),
                normalize_text(&track.artists.join(" "))
            ))
        })
        .map(|track| {
            let exact = track
                .genres
                .iter()
                .any(|genre| source_genres.contains(genre));
            let near = track.genres.iter().any(|genre| adjacent.contains(genre));
            let zone = if exact {
                0
            } else if near {
                1
            } else {
                2
            };
            let energy_fit = track
                .energy_score
                .map(|value| 1.0 - (value - avg_energy).abs())
                .unwrap_or(0.5);
            let popularity = track.popularity.unwrap_or(0.5);
            let score = match zone {
                0 => 0.62 + 0.25 * energy_fit + 0.13 * popularity,
                1 => 0.52 + 0.28 * energy_fit + 0.10 * popularity,
                _ => 0.35 + 0.25 * energy_fit + 0.10 * popularity,
            };
            (zone, score, track)
        })
        .collect();
    scored.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| b.1.total_cmp(&a.1)));

    let top_core = report
        .core_preferences
        .first()
        .cloned()
        .unwrap_or_else(|| "当前偏好".into());
    let mut result = Vec::new();
    for zone in 0..=2 {
        let take = if zone == 0 { 4 } else { 3 };
        for (_, score, track) in scored.iter().filter(|item| item.0 == zone).take(take) {
            let target = track
                .genres
                .first()
                .cloned()
                .unwrap_or_else(|| "新风格".into());
            let (zone_label, novelty, reason, expansion) = match zone {
                0 => (
                    "舒适区",
                    0.36,
                    format!("延续你在 {top_core} 中已经形成的听感锚点"),
                    format!("在相近风格中发现新的歌手与作品"),
                ),
                1 => (
                    "拓展区",
                    0.70,
                    format!("保留 {top_core} 的部分特征，同时引入 {target}"),
                    format!("从 {top_core} 平滑进入 {target}"),
                ),
                _ => (
                    "惊喜区",
                    0.89,
                    format!("用接近的能量和情绪作为桥梁，尝试更远的 {target}"),
                    format!("扩大语言、年代或编曲维度"),
                ),
            };
            result.push(Recommendation {
                track: track.clone(),
                zone: zone_label.into(),
                reason,
                connection: format!("与你歌单的平均能量和主要情绪保持可接受距离"),
                expansion,
                match_score: score.clamp(0.0, 0.98),
                novelty_score: novelty,
            });
        }
    }
    result
}

fn build_route(report: &TasteReport, recommendations: &[Recommendation]) -> Vec<RouteStep> {
    let core = report
        .core_preferences
        .first()
        .cloned()
        .unwrap_or_else(|| "当前偏好".into());
    let mut used = HashSet::from([core.clone()]);
    let mut route = vec![route_step(
        core,
        "从歌单中出现频率最高的风格出发",
        "舒适区",
        recommendations,
    )];

    if let Some(genre) = select_route_genre(
        &report.adjacent_preferences,
        "拓展区",
        recommendations,
        &used,
    ) {
        used.insert(genre.clone());
        route.push(route_step(
            genre,
            "保留熟悉的节奏、音色或情绪，增加一个新变量",
            "拓展区",
            recommendations,
        ));
    }

    if let Some(genre) = select_route_genre(
        &report.unexplored_preferences,
        "惊喜区",
        recommendations,
        &used,
    ) {
        route.push(route_step(
            genre,
            "用能量与情绪相近作为桥梁，尝试更远的声音",
            "惊喜区",
            recommendations,
        ));
    }

    route
}

fn select_route_genre(
    preferred: &[String],
    zone: &str,
    recommendations: &[Recommendation],
    used: &HashSet<String>,
) -> Option<String> {
    let available: HashSet<&str> = recommendations
        .iter()
        .filter(|item| item.zone == zone)
        .flat_map(|item| item.track.genres.iter().map(String::as_str))
        .collect();

    preferred
        .iter()
        .find(|genre| !used.contains(*genre) && available.contains(genre.as_str()))
        .cloned()
        .or_else(|| {
            recommendations
                .iter()
                .filter(|item| item.zone == zone)
                .flat_map(|item| item.track.genres.iter())
                .find(|genre| !used.contains(*genre))
                .cloned()
        })
}

fn route_step(
    genre: String,
    explanation: &str,
    zone: &str,
    recommendations: &[Recommendation],
) -> RouteStep {
    RouteStep {
        tracks: recommendations
            .iter()
            .filter(|item| item.zone == zone && item.track.genres.contains(&genre))
            .take(3)
            .map(|item| item.track.clone())
            .collect(),
        genre,
        explanation: explanation.into(),
    }
}

fn recommendation_pool() -> Vec<Track> {
    vec![
        local_track(
            "Tadow",
            "Masego & FKJ",
            &["Neo Soul", "Jazz R&B"],
            2018,
            "英语",
            0.63,
            0.72,
        ),
        local_track(
            "Get You",
            "Daniel Caesar",
            &["Neo Soul", "R&B / Soul"],
            2017,
            "英语",
            0.46,
            0.78,
        ),
        local_track(
            "Pink + White",
            "Frank Ocean",
            &["Alternative R&B", "Art Pop"],
            2016,
            "英语",
            0.49,
            0.82,
        ),
        local_track(
            "Ditto",
            "NewJeans",
            &["K-Pop", "Alternative R&B"],
            2022,
            "韩语",
            0.52,
            0.91,
        ),
        local_track(
            "INVU",
            "TAEYEON",
            &["K-Pop", "Synthpop"],
            2022,
            "韩语",
            0.67,
            0.84,
        ),
        local_track(
            "Love Dive",
            "IVE",
            &["K-Pop", "Dance Pop"],
            2022,
            "韩语",
            0.72,
            0.93,
        ),
        local_track(
            "505",
            "Arctic Monkeys",
            &["Indie Rock", "Alternative Rock"],
            2007,
            "英语",
            0.76,
            0.90,
        ),
        local_track(
            "Somebody Else",
            "The 1975",
            &["Indie Pop", "Alternative R&B"],
            2016,
            "英语",
            0.58,
            0.88,
        ),
        local_track(
            "Dreams",
            "The Cranberries",
            &["Alternative Rock", "Dream Pop"],
            1993,
            "英语",
            0.61,
            0.86,
        ),
        local_track(
            "Space Song",
            "Beach House",
            &["Dream Pop", "Indie Pop"],
            2015,
            "英语",
            0.42,
            0.86,
        ),
        local_track(
            "Blinding Lights",
            "The Weeknd",
            &["Pop", "Synthpop"],
            2019,
            "英语",
            0.79,
            0.98,
        ),
        local_track(
            "bad guy",
            "Billie Eilish",
            &["Alternative Pop", "Pop"],
            2019,
            "英语",
            0.70,
            0.94,
        ),
        local_track(
            "Cruel Summer",
            "Taylor Swift",
            &["Pop", "Synthpop"],
            2019,
            "英语",
            0.76,
            0.97,
        ),
        local_track(
            "Levitating",
            "Dua Lipa",
            &["Dance Pop", "Disco"],
            2020,
            "英语",
            0.83,
            0.96,
        ),
        local_track(
            "晴天",
            "周杰伦",
            &["Mandopop", "C-Pop"],
            2003,
            "中文",
            0.52,
            0.97,
        ),
        local_track(
            "淘汰",
            "陈奕迅",
            &["Mandopop", "C-Pop"],
            2007,
            "中文",
            0.44,
            0.92,
        ),
        local_track(
            "光年之外",
            "G.E.M. 邓紫棋",
            &["Mandopop", "Pop Rock"],
            2016,
            "中文",
            0.72,
            0.95,
        ),
        local_track(
            "平凡之路",
            "朴树",
            &["Chinese Indie", "Folk Rock"],
            2014,
            "中文",
            0.55,
            0.92,
        ),
        local_track(
            "Plastic Love",
            "Mariya Takeuchi",
            &["City Pop", "J-Pop"],
            1984,
            "日语",
            0.61,
            0.95,
        ),
        local_track(
            "First Love",
            "宇多田光",
            &["J-Pop", "Japanese R&B"],
            1999,
            "日语",
            0.42,
            0.96,
        ),
        local_track(
            "Shinunoga E-Wa",
            "Fujii Kaze",
            &["J-Pop", "Japanese R&B"],
            2020,
            "日语",
            0.59,
            0.90,
        ),
        local_track(
            "夜に駆ける",
            "YOASOBI",
            &["J-Pop", "Electronic Pop"],
            2019,
            "日语",
            0.82,
            0.96,
        ),
        local_track(
            "From The Start",
            "Laufey",
            &["Jazz Pop", "Bossa Nova"],
            2023,
            "英语",
            0.48,
            0.90,
        ),
        local_track(
            "Blue in Green",
            "Miles Davis",
            &["Jazz", "Modal Jazz"],
            1959,
            "器乐",
            0.28,
            0.83,
        ),
        local_track(
            "Clair de Lune",
            "Claude Debussy",
            &["Classical", "Impressionism"],
            1905,
            "器乐",
            0.18,
            0.91,
        ),
        local_track(
            "Redbone",
            "Childish Gambino",
            &["Psychedelic Soul", "Alternative R&B"],
            2016,
            "英语",
            0.66,
            0.93,
        ),
        local_track(
            "N.Y. State of Mind",
            "Nas",
            &["Hip-Hop / Rap", "Boom Bap"],
            1994,
            "英语",
            0.70,
            0.90,
        ),
        local_track(
            "See You Again",
            "Tyler, The Creator",
            &["Alternative Hip-Hop", "Neo Soul"],
            2017,
            "英语",
            0.67,
            0.94,
        ),
        local_track(
            "Midnight City",
            "M83",
            &["Synthpop", "Electronic"],
            2011,
            "英语",
            0.82,
            0.94,
        ),
        local_track(
            "Innerbloom",
            "RÜFÜS DU SOL",
            &["Electronic", "Progressive House"],
            2015,
            "英语",
            0.66,
            0.88,
        ),
    ]
}

fn local_track(
    title: &str,
    artist: &str,
    genres: &[&str],
    year: u16,
    language: &str,
    energy: f32,
    popularity: f32,
) -> Track {
    let (moods, _) = genre_features(genres.first().copied().unwrap_or("Pop"));
    let search = urlencoding::encode(&format!("{} {}", artist, title)).into_owned();
    Track {
        id: Uuid::new_v4().to_string(),
        title: title.into(),
        normalized_title: normalize_text(title),
        artists: vec![artist.into()],
        album: None,
        genres: genres.iter().map(|value| (*value).to_string()).collect(),
        release_year: Some(year),
        language: Some(language.into()),
        duration_ms: None,
        platform: "local_recommendation_catalog".into(),
        platform_url: Some(format!("https://music.apple.com/cn/search?term={search}")),
        external_ids: Default::default(),
        version_type: VersionType::Original,
        mood_tags: moods,
        energy_score: Some(energy),
        popularity: Some(popularity),
        metadata_confidence: 0.82,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn local_profile_enriches_known_artist() {
        let mut track = Track {
            id: "1".into(),
            title: "instagram".into(),
            normalized_title: "instagram".into(),
            artists: vec!["DEAN".into()],
            album: None,
            genres: vec!["待补全".into()],
            release_year: None,
            language: None,
            duration_ms: None,
            platform: "manual".into(),
            platform_url: None,
            external_ids: Default::default(),
            version_type: VersionType::Original,
            mood_tags: vec![],
            energy_score: None,
            popularity: None,
            metadata_confidence: 0.4,
        };
        apply_local_artist_profile(&mut track);
        assert!(track.genres.iter().any(|genre| genre.contains("R&B")));
        assert!(track.energy_score.is_some());
    }

    #[test]
    fn recommendation_pool_has_multiple_genres() {
        let genres: HashSet<_> = recommendation_pool()
            .into_iter()
            .flat_map(|track| track.genres)
            .collect();
        assert!(genres.len() > 10);
    }

    #[test]
    fn exploration_route_has_distinct_genres_and_matching_tracks() {
        let playlist = Playlist {
            id: "route-test".into(),
            name: "路线去重测试".into(),
            owner_label: "test".into(),
            source: "test".into(),
            is_demo: false,
            tracks: vec![
                local_track(
                    "Source One",
                    "Artist One",
                    &["Alternative R&B", "Korean R&B"],
                    2020,
                    "英语",
                    0.55,
                    0.5,
                ),
                local_track(
                    "Source Two",
                    "Artist Two",
                    &["Alternative R&B"],
                    2021,
                    "英语",
                    0.58,
                    0.5,
                ),
            ],
        };
        let report = engine::analyze_playlist(&playlist);
        let recommendations = build_local_recommendations(&playlist, &report);
        let route = build_route(&report, &recommendations);
        let genres: HashSet<_> = route.iter().map(|step| step.genre.as_str()).collect();

        assert_eq!(
            route.first().map(|step| &step.genre),
            report.core_preferences.first()
        );
        assert_eq!(route.len(), 3);
        assert_eq!(genres.len(), route.len(), "路线中不得出现重复 Genre");
        assert!(route.windows(2).all(|pair| pair[0].genre != pair[1].genre));
        assert!(route.iter().all(|step| {
            !step.tracks.is_empty()
                && step
                    .tracks
                    .iter()
                    .all(|track| track.genres.contains(&step.genre))
        }));
    }

    #[test]
    fn exploration_route_shortens_when_distinct_genres_are_unavailable() {
        let playlist = Playlist {
            id: "short-route-test".into(),
            name: "短路线测试".into(),
            owner_label: "test".into(),
            source: "test".into(),
            is_demo: false,
            tracks: vec![local_track(
                "Source",
                "Artist",
                &["Alternative R&B"],
                2020,
                "英语",
                0.55,
                0.5,
            )],
        };
        let report = engine::analyze_playlist(&playlist);
        let recommendations = vec![Recommendation {
            track: local_track(
                "Only Match",
                "Another Artist",
                &["Alternative R&B"],
                2022,
                "英语",
                0.57,
                0.5,
            ),
            zone: "舒适区".into(),
            reason: String::new(),
            connection: String::new(),
            expansion: String::new(),
            match_score: 0.9,
            novelty_score: 0.2,
        }];

        let route = build_route(&report, &recommendations);
        assert_eq!(route.len(), 1);
        assert_eq!(route[0].genre, "Alternative R&B");
    }
}
