use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum VersionType {
    Original,
    Live,
    Remix,
    Remastered,
    Acoustic,
    Cover,
    Instrumental,
    Unknown,
}

impl Default for VersionType {
    fn default() -> Self {
        Self::Original
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Track {
    pub id: String,
    pub title: String,
    pub normalized_title: String,
    pub artists: Vec<String>,
    pub album: Option<String>,
    pub genres: Vec<String>,
    pub release_year: Option<u16>,
    pub language: Option<String>,
    pub duration_ms: Option<u32>,
    pub platform: String,
    pub platform_url: Option<String>,
    #[serde(default)]
    pub external_ids: HashMap<String, String>,
    #[serde(default)]
    pub version_type: VersionType,
    #[serde(default)]
    pub mood_tags: Vec<String>,
    pub energy_score: Option<f32>,
    pub popularity: Option<f32>,
    pub metadata_confidence: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Playlist {
    pub id: String,
    pub name: String,
    pub owner_label: String,
    pub source: String,
    pub is_demo: bool,
    pub tracks: Vec<Track>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TasteMetric {
    pub label: String,
    pub value: f32,
    pub display: String,
    pub explanation: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Recommendation {
    pub track: Track,
    pub zone: String,
    pub reason: String,
    pub connection: String,
    pub expansion: String,
    pub match_score: f32,
    pub novelty_score: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteStep {
    pub genre: String,
    pub explanation: String,
    pub tracks: Vec<Track>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TasteReport {
    pub playlist_name: String,
    pub source_label: String,
    pub is_demo: bool,
    pub track_count: usize,
    pub genre_distribution: Vec<(String, usize)>,
    pub artist_distribution: Vec<(String, usize)>,
    pub era_distribution: Vec<(String, usize)>,
    pub metrics: Vec<TasteMetric>,
    pub core_preferences: Vec<String>,
    pub adjacent_preferences: Vec<String>,
    pub unexplored_preferences: Vec<String>,
    pub summary: String,
    pub confidence: f32,
    pub limitations: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PersonalDemo {
    pub playlist: Playlist,
    pub report: TasteReport,
    pub recommendations: Vec<Recommendation>,
    pub route: Vec<RouteStep>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BridgeTrack {
    pub track: Track,
    pub reason: String,
    pub phase: String,
    pub bridge_score: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComparisonReport {
    pub user_a: String,
    pub user_b: String,
    pub metrics: Vec<TasteMetric>,
    pub shared_genres: Vec<String>,
    pub user_a_signatures: Vec<String>,
    pub user_b_signatures: Vec<String>,
    pub summary: String,
    pub bridge_playlist: Vec<BridgeTrack>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DemoPayload {
    pub generated_at: String,
    pub disclosure: String,
    pub personal: PersonalDemo,
    pub comparison: ComparisonReport,
    pub available_playlists: Vec<Playlist>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum MatchStatus {
    Matched,
    NeedsConfirmation,
    Unmatched,
    Selected,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchCandidate {
    pub target_track_id: String,
    pub title: String,
    pub artists: Vec<String>,
    pub album: Option<String>,
    pub target_url: Option<String>,
    pub version_type: VersionType,
    pub confidence: f32,
    pub match_reason: String,
    pub available_in_market: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlatformTrackMatch {
    pub source_track: Track,
    pub target_platform: String,
    pub target_track_id: Option<String>,
    pub target_url: Option<String>,
    pub version_type: VersionType,
    pub confidence: f32,
    pub match_reason: String,
    pub status: MatchStatus,
    #[serde(default)]
    pub candidates: Vec<MatchCandidate>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrackFailure {
    pub track: Track,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlaylistExportResult {
    pub playlist_name: String,
    pub platform: String,
    pub playlist_url: Option<String>,
    pub requested_count: usize,
    pub added_count: usize,
    pub failed_count: usize,
    pub needs_confirmation_count: usize,
    pub successful_tracks: Vec<PlatformTrackMatch>,
    pub failed_tracks: Vec<TrackFailure>,
    pub ambiguous_tracks: Vec<PlatformTrackMatch>,
    pub is_demo: bool,
    pub disclosure: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WriterStatus {
    pub platform: String,
    pub label: String,
    pub availability: String,
    pub authorized: bool,
    pub is_demo: bool,
    pub message: String,
}

/// 服务端生成的平台能力说明。前端只展示该接口返回的事实，不自行宣称已接通。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlatformCapability {
    pub platform: String,
    pub display_name: String,
    pub region: String,
    pub capability_status: String,
    pub status_label: String,
    pub account_connection: String,
    pub public_playlist_links: String,
    pub playlist_read: String,
    pub playlist_write: String,
    pub search_links: bool,
    pub requires_review: bool,
    pub configured: bool,
    pub official_docs_url: Option<String>,
    pub action_kind: String,
    pub description: String,
    pub policy_notice: Option<String>,
    pub data_use: DataUseCapabilities,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataUseCapabilities {
    pub can_read_account_identity: bool,
    pub can_list_playlists: bool,
    pub can_read_playlist_items: bool,
    pub can_display_attributed_metadata: bool,
    pub can_transfer_playlist_metadata: bool,
    pub can_create_playlist: bool,
    pub can_add_items: bool,
    pub can_analyze_content: bool,
    pub can_derive_metrics: bool,
    pub can_cross_platform_compare: bool,
    pub can_send_to_llm: bool,
    pub can_train_model: bool,
    pub explanation: String,
}

impl DataUseCapabilities {
    pub fn unavailable(explanation: impl Into<String>) -> Self {
        Self {
            can_read_account_identity: false,
            can_list_playlists: false,
            can_read_playlist_items: false,
            can_display_attributed_metadata: false,
            can_transfer_playlist_metadata: false,
            can_create_playlist: false,
            can_add_items: false,
            can_analyze_content: false,
            can_derive_metrics: false,
            can_cross_platform_compare: false,
            can_send_to_llm: false,
            can_train_model: false,
            explanation: explanation.into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderConfigurationStatus {
    pub platform: String,
    pub display_name: String,
    pub configured: bool,
    pub validation_status: String,
    pub required_environment_variables: Vec<String>,
    pub present_environment_variables: Vec<String>,
    pub missing_environment_variables: Vec<String>,
    pub redirect_uri: Option<String>,
    pub dashboard_url: String,
    pub setup_steps: Vec<String>,
    pub secrets_exposed_to_frontend: bool,
    pub message: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct PlaylistLinkRequest {
    pub url: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlaylistLinkInspection {
    pub platform: Option<String>,
    pub platform_label: Option<String>,
    pub recognized: bool,
    pub playlist_id: Option<String>,
    pub normalized_url: Option<String>,
    pub resolved_url: Option<String>,
    pub publicly_accessible: Option<bool>,
    pub access_status: String,
    pub structured_data_status: String,
    pub playlist_name: Option<String>,
    pub track_count: Option<usize>,
    pub preview_tracks: Vec<Track>,
    pub can_analyze: bool,
    pub message: String,
    pub next_step: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpotifyConnectionStatus {
    pub configured: bool,
    pub connected: bool,
    pub user_id: Option<String>,
    pub display_name: Option<String>,
    pub avatar_url: Option<String>,
    pub message: String,
    pub policy_notice: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpotifyPlaylistSummary {
    pub id: String,
    pub name: String,
    pub owner_name: String,
    pub track_count: usize,
    pub collaborative: bool,
    pub public: Option<bool>,
    pub spotify_url: Option<String>,
    pub image_url: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct SpotifyImportRequest {
    pub playlist_ids: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpotifyImportedPlaylist {
    pub id: String,
    pub name: String,
    pub spotify_url: Option<String>,
    pub imported_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpotifyImportResult {
    pub playlists: Vec<SpotifyImportedPlaylist>,
    pub tracks: Vec<Track>,
    pub track_count: usize,
    pub data_use: DataUseCapabilities,
    pub policy_notice: String,
    pub attribution: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YoutubeConnectionStatus {
    pub configured: bool,
    pub connected: bool,
    pub channel_id: Option<String>,
    pub display_name: Option<String>,
    pub avatar_url: Option<String>,
    pub message: String,
    pub policy_notice: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YoutubePlaylistSummary {
    pub id: String,
    pub name: String,
    pub owner_name: String,
    pub item_count: usize,
    pub privacy_status: Option<String>,
    pub youtube_url: String,
    pub image_url: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct YoutubeImportRequest {
    pub playlist_ids: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YoutubeImportedPlaylist {
    pub id: String,
    pub name: String,
    pub youtube_url: String,
    pub imported_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct YoutubeImportResult {
    pub playlists: Vec<YoutubeImportedPlaylist>,
    pub tracks: Vec<Track>,
    pub track_count: usize,
    pub data_use: DataUseCapabilities,
    pub policy_notice: String,
    pub attribution: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppleMusicBootstrap {
    pub configured: bool,
    pub developer_token: Option<String>,
    pub app_name: String,
    pub app_build: String,
    pub real_account_validation: String,
    pub message: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ManualAnalyzeRequest {
    pub name: Option<String>,
    pub text: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ExportPreviewRequest {
    pub platform: String,
    pub playlist_name: String,
    pub tracks: Vec<Track>,
    pub format: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExportPreview {
    pub preview_id: String,
    pub platform: String,
    pub playlist_name: String,
    pub matches: Vec<PlatformTrackMatch>,
    pub requested_count: usize,
    pub auto_matched_count: usize,
    pub needs_confirmation_count: usize,
    pub unmatched_count: usize,
    pub requires_explicit_confirmation: bool,
    pub is_demo: bool,
    pub disclosure: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ExportExecuteRequest {
    pub preview_id: String,
    pub confirmed: bool,
    #[serde(default)]
    pub selections: HashMap<String, String>,
}

#[derive(Debug, Clone)]
pub struct StoredPreview {
    pub preview: ExportPreview,
    pub format: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentSettings {
    pub endpoint: String,
    pub model: String,
    pub temperature: f32,
    pub max_tokens: u32,
    pub max_agent_steps: u32,
    pub request_timeout_seconds: u64,
    pub retry_limit: u32,
    pub max_cost_usd: f64,
    pub input_price_per_million: f64,
    pub output_price_per_million: f64,
    #[serde(default, skip_deserializing)]
    pub api_key_available: bool,
}

impl Default for AgentSettings {
    fn default() -> Self {
        Self {
            endpoint: "https://api.openai.com/v1".into(),
            model: "gpt-5-mini".into(),
            temperature: 0.3,
            max_tokens: 1_200,
            max_agent_steps: 16,
            request_timeout_seconds: 30,
            retry_limit: 2,
            max_cost_usd: 0.50,
            input_price_per_million: 0.0,
            output_price_per_million: 0.0,
            api_key_available: std::env::var("OPENAI_API_KEY").is_ok(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct CreateAgentTaskRequest {
    pub scenario: String,
    pub goal: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, sqlx::FromRow)]
pub struct AgentTask {
    pub id: String,
    pub scenario: String,
    pub goal: String,
    pub status: String,
    pub current_step: i64,
    pub max_steps: i64,
    pub progress: f32,
    pub message: String,
    pub input_tokens: i64,
    pub output_tokens: i64,
    pub estimated_cost_usd: f64,
    pub result_json: Option<String>,
    pub error: Option<String>,
    pub created_at: i64,
    pub updated_at: i64,
    pub revision: i64,
}
